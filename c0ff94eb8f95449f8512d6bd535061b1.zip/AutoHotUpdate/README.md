# 素材热更工具（Android）

一个安卓 App：把素材文件放进指定文件夹后，点击【写入File】，自动生成文件夹内所有文件（**File.txt 除外**）的 md5 与 size 清单，写入该文件夹的 `File.txt`。

## 生成的 File.txt 格式

```
[文件名.扩展名]
md5=生成的md5值
size=生成的size值

[另一个文件.png]
md5=xxxx
size=12345

```

- 若 `File.txt` 里已有某文件的信息，只**替换**其 md5 与 size，保留原条目位置；
- 文件夹里新增的文件会**追加**到末尾；
- 已从文件夹移除的文件，其原条目会**保留**（不自动删除，便于复核——如你希望删除，可在规则里注明，我来改）。

## 如何编译成 APK

1. 安装 [Android Studio](https://developer.android.com/studio)（建议较新版本）。
2. 用 Android Studio 打开本工程根目录（`AutoHotUpdate` 文件夹）。首次打开会自动下载 Gradle 8.2 并完成配置。
3. 等待同步完成后，菜单 **Build → Build Bundle(s) / APK(s) → Build APK(s)**。
4. APK 输出在 `app/build/outputs/apk/debug/app-debug.apk`，安装到手机即可。

> 工程使用系统文件夹选择器（SAF）读写文件夹，**无需申请任何存储权限**，Android 8.0 及以上均可运行。

## 使用方法（App 内）

1. 点击【选择文件夹】，在系统选择器中选中素材所在的文件夹。
2. 把素材文件放进该文件夹（可含 `File.txt`，也可不含，首次会自动创建）。
3. 点击【写入File】，下方会显示本次更新的文件数量及各自的 md5/size。
4. 将文件夹同步出去时，把 `File.txt` 一起带上即可作为热更清单。

## 项目结构

```
AutoHotUpdate/
├── settings.gradle / build.gradle / gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/example/autohotupdate/MainActivity.kt   # 全部核心逻辑
        └── res/  (布局、主题、图标、字符串)
```

> 桌面版同规则脚本：见工程外 `auto_hot_update.py`，可在任意电脑运行，用于先在本地验证逻辑或直接批量生成 File.txt。
