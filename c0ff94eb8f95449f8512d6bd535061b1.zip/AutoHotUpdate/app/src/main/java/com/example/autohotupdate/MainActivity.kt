package com.example.autohotupdate

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import com.google.android.material.button.MaterialButton
import java.security.MessageDigest

class MainActivity : AppCompatActivity() {

    private companion object {
        /** 清单文件名（始终排除，不参与计算） */
        const val FILE_INDEX = "File.txt"
        const val PREFS = "hot_update_prefs"
        const val KEY_URI = "folder_uri"

        /** File.txt 中各文件条目的字段前缀 */
        const val PREFIX_MD5 = "md5="
        const val PREFIX_SIZE = "size="
    }

    private var folderDoc: DocumentFile? = null

    private lateinit var tvFolder: TextView
    private lateinit var tvResult: TextView
    private lateinit var btnWrite: MaterialButton

    // 系统文件夹选择器(SAF)：返回所选文件夹的持久化 URI，可反复读写，无需申请存储权限
    private val pickFolderLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val uri = result.data!!.data
                if (uri != null) onFolderPicked(uri)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvFolder = findViewById(R.id.tvFolder)
        tvResult = findViewById(R.id.tvResult)
        val btnPickFolder = findViewById<MaterialButton>(R.id.btnPickFolder)
        btnWrite = findViewById(R.id.btnWrite)

        btnPickFolder.setOnClickListener { pickFolder() }
        btnWrite.setOnClickListener { writeFileIndex() }

        // 恢复上次选择并授权的文件夹
        val savedUri = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_URI, null)
        if (savedUri != null) {
            val uri = Uri.parse(savedUri)
            folderDoc = DocumentFile.fromTreeUri(this, uri)
            updateFolderDisplay()
        }
    }

    private fun pickFolder() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
        pickFolderLauncher.launch(intent)
    }

    private fun onFolderPicked(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (e: Exception) {
            // 某些提供方可能不支持持久授权，忽略即可，本次会话内仍可用
        }
        getSharedPreferences(PREFS, MODE_PRIVATE)
            .edit().putString(KEY_URI, uri.toString()).apply()
        folderDoc = DocumentFile.fromTreeUri(this, uri)
        updateFolderDisplay()
    }

    private fun updateFolderDisplay() {
        val doc = folderDoc
        tvFolder.text = doc?.uri?.toString() ?: getString(R.string.no_folder)
        btnWrite.isEnabled = doc != null
    }

    // ------------------------------------------------------------------
    // 核心逻辑：扫描文件 -> 计算 md5 / size -> 合并写回 File.txt
    // ------------------------------------------------------------------

    private fun writeFileIndex() {
        val root = folderDoc
        if (root == null) {
            toast("请先选择文件夹")
            return
        }

        // 1) 遍历文件夹内的文件（排除 File.txt，跳过子目录）
        val entries = mutableListOf<FileEntry>()
        root.listFiles()
            .filter { it.isFile && it.name != FILE_INDEX }
            .forEach { file ->
                val (md5, size) = computeMd5AndSize(file)
                entries.add(FileEntry(file.name ?: "unknown", md5, size))
            }

        if (entries.isEmpty()) {
            tvResult.text = "文件夹内没有可处理的文件（File.txt 除外）。"
            return
        }

        // 2) 读取现有 File.txt
        val oldContent = readIndexFile(root)

        // 3) 合并：已有条目只替换 md5/size，新增条目追加
        val newContent = mergeIndex(oldContent, entries)

        // 4) 写回 File.txt
        val ok = writeIndexFile(root, newContent)

        // 5) 结果展示
        val sb = StringBuilder()
        if (ok) {
            sb.append("✅ 已更新 ${entries.size} 个文件到 File.txt\n")
            entries.forEach { e ->
                sb.append("  [${e.name}] size=${e.size} md5=${e.md5.take(12)}…\n")
            }
        } else {
            sb.append("❌ 写入 File.txt 失败，请检查文件夹权限。")
        }
        tvResult.text = sb.toString()
    }

    /** 计算单个文件的 MD5 与字节大小（size 为字节数） */
    private fun computeMd5AndSize(file: DocumentFile): Pair<String, Long> {
        val md = MessageDigest.getInstance("MD5")
        var size = 0L
        contentResolver.openInputStream(file.uri)?.use { ins ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
                size += n
            }
        }
        val hex = md.digest().joinToString("") { String.format("%02x", it) }
        return hex to size
    }

    /** 读取 File.txt 现有内容（不存在则返回空串） */
    private fun readIndexFile(root: DocumentFile): String {
        val f = root.findFile(FILE_INDEX) ?: return ""
        if (!f.isFile) return ""
        val sb = StringBuilder()
        contentResolver.openInputStream(f.uri)?.use { ins ->
            sb.append(ins.readBytes().toString(Charsets.UTF_8))
        }
        return sb.toString()
    }

    /** 将合并结果写回 File.txt（不存在则新建） */
    private fun writeIndexFile(root: DocumentFile, content: String): Boolean {
        val file = root.findFile(FILE_INDEX) ?: root.createFile("text/plain", FILE_INDEX) ?: return false
        val out = contentResolver.openOutputStream(file.uri, "wt") ?: return false
        return try {
            out.write(content.toByteArray(Charsets.UTF_8))
            true
        } catch (e: Exception) {
            false
        } finally {
            runCatching { out.close() }
        }
    }

    /**
     * 合并规则：
     * - 保留 File.txt 原有条目顺序；
     * - 若某文件仍存在于文件夹中，仅替换其 md5 与 size；
     * - 若某文件已从文件夹移除，保留其原条目（不误删，便于复核）；
     * - 文件夹中新增、且 File.txt 中没有的文件，追加到末尾。
     */
    private fun mergeIndex(oldContent: String, entries: List<FileEntry>): String {
        // 解析旧内容 -> 有序 Map: 文件名 -> 原条目
        val oldBlocks = parseIndex(oldContent)
        val sb = StringBuilder()
        val seen = HashSet<String>()

        // 按原顺序输出；命中的文件用新值，未命中的原样保留
        oldBlocks.forEach { (name, block) ->
            val e = entries.firstOrNull { it.name == name }
            if (e != null) {
                appendBlock(sb, name, e.md5, e.size)
            } else {
                appendBlock(sb, name, block.md5, block.size)
            }
            seen.add(name)
        }

        // 追加新文件
        entries.forEach { e ->
            if (e.name !in seen) {
                appendBlock(sb, e.name, e.md5, e.size)
            }
        }
        return sb.toString()
    }

    private fun appendBlock(sb: StringBuilder, name: String, md5: String?, size: Long?) {
        sb.append("[$name]\n")
        if (md5 != null) sb.append("$PREFIX_MD5$md5\n")
        if (size != null) sb.append("$PREFIX_SIZE$size\n")
        sb.append("\n")
    }

    /** 把 File.txt 文本解析为有序的 文件名 -> 原条目 */
    private fun parseIndex(content: String): LinkedHashMap<String, Block> {
        val blocks = LinkedHashMap<String, Block>()
        var current: Block? = null
        content.lines().forEach { raw ->
            val line = raw.trim()
            when {
                line.startsWith("[") && line.endsWith("]") -> {
                    val name = line.substring(1, line.length - 1)
                    current = Block(null, null)
                    blocks[name] = current
                }
                line.startsWith(PREFIX_MD5) && current != null ->
                    current.md5 = line.substring(PREFIX_MD5.length).trim()
                line.startsWith(PREFIX_SIZE) && current != null ->
                    current.size = line.substring(PREFIX_SIZE.length).trim()
            }
        }
        return blocks
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    // 数据结构
    private data class FileEntry(val name: String, val md5: String, val size: Long)

    private class Block(var md5: String?, var size: String?)
}
